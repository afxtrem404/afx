require('../../utils/PrototypeFunctions')
const { getBinData } = require('../../utils/checker-bin')
const request = require('request-promise')
const Checker = require('../../checker')
const binsu = require('../../scrapper/binsu')
const fs = require('fs')

class Card {
  constructor(db, message) {
    this.Cards = db.Cards
    this.Level = db.Level
    this.message = message
    this.checker = new Checker(db)
  }

  async binLookup(card) {
    if (card.length < 6)
      return { success: false, message: 'bin inválida' }
    try {
      return { success: true, response: getBinData(card.slice(0, 6)) }
    } catch ({ message }) {
      return {
        success: false,
        response: 'Base bins.su indisponível.\nDebug: ' + message,
      }
    }
  }

  async formatarCartoes(
    cartoes = [],
    ignoreAny = true,
    ggChecker = false
  ) {
    try {
      const details = {
        repeats: 0,
        invalids: 0,
        exists: 0,
      }

      const cards = cartoes
        .split('\n')
        .map((card) => {
          const matchOne = card.match(
            /(?<number>\d{15,16}).(?<month>\d{1,2}).(?<year>\d{2,4}).(?<cvv>\d{3,4}).?(?<firstExtraField>(?:[0-9A-z\.\s-]|[\w])+)?.?(?<secondExtraField>[0-9A-z\.\s-]+)?/
          )
          return matchOne
        })
        .filter((match) => {
          if (match?.length || match?.groups) return match
          else details.invalids++
        })
        .filter((match) => {
          if (match.groups.number && match.groups.number.luhn())
            return match
          else details.invalids++
        })
        .map(({ groups: card }) => {
          const removeAccents = (text) =>
            text.normalize('NFD').replace(/[^a-zA-Z\s]/g, '')

          const checks = new Map()
          const fields = [
            card?.firstExtraField,
            card?.secondExtraField,
          ]

          fields
            .filter((field) => field)
            .forEach((field) => {
              const cpfFormat = field.replace(/[^0-9]/g, '')
              const nameFormat = removeAccents(field)
                .replace(/[^A-z\s]/g, '')
                .trim()

              if (!isNaN(cpfFormat) && cpfFormat.length === 11)
                checks.set('cpf', cpfFormat)
              else if (isNaN(nameFormat))
                checks.set('name', nameFormat)
            })

          if (checks.size === 2) {
            const holderCpf = checks.get('cpf')
            const holderName = checks.get('name')

            const theCard = {
              number: card.number,
              month: card.month,
              year: card.year,
              cvv: card.cvv,
              holderName,
              holderCpf,
            }

            console.log(theCard, checks)

            return theCard
          }

          return {
            number: card.number,
            month: card.month,
            year: card.year,
            cvv: card.cvv,
          }
        })
        .filter(
          (
            (set) => (c) =>
              !set.has(c.number) && set.add(c.number)
                ? true
                : (details.repeats++, false)
          )(new Set())
        )

      if (!cards.length)
        return {
          success: false,
          response: '<b>Nenhum cartão válido encontrado.</b>',
          debug: `${cards.length} ${
            cards.length > 1 ? 'cartões' : 'cartão'
          } Inválido(s)`,
        }

      let cartoesArrayNaoExistentes = []

      for (let card of cards) {
        const number = card.number
        let bin = await this.binLookup(number)

        const exists = ignoreAny
          ? await this.Cards.exists({ number: number })
          : false

        if (!bin.success)
          return {
            success: false,
            response: '<b>' + bin.response + '</b>',
            debug: bin.response,
          }

        if (!exists)
          cartoesArrayNaoExistentes.push({
            card: card,
            bin: bin.response,
          })
        else details.exists++
      }

      if (!cartoesArrayNaoExistentes.length)
        return {
          success: false,
          response: '<b>☑️ Cartões já adicionados.</b>',
          debug: `${details.exists} ${
            details.exists > 1 ? 'cartões' : 'cartão'
          } já existente(s) no banco de dados.`,
        }

      return {
        success: true,
        response: cartoesArrayNaoExistentes,
        total: cartoesArrayNaoExistentes.length,
        details,
      }
    } catch (e) {
      console.log(e)
      return {
        success: false,
        response: '<b>Falha ao adicionar.</b>',
        debug: e?.error ?? e?.message,
      }
    }
  }

  async cartaoRandomico() {
    try {
      const totalCards = await this.Cards.find({ restrict: false })

      if (totalCards.shuffle()[0]) {
        return {
          success: true,
          response: totalCards.shuffle()[0],
        }
      } else {
        return {
          success: false,
          response: '<b>Nenhum Cartão disponível</b>',
        }
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async totalQuantidade() {
    try {
      const totalCards = await this.Cards.countDocuments({
        restrict: false,
      })

      return {
        success: true,
        response: totalCards,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async checarCartao() {
    return { success: false }
  }

  async total() {
    try {
      const totalCards = await this.Cards.find({
        restrict: false,
      }).populate('level')

      return {
        success: true,
        response: totalCards,
      }
    } catch (e) {
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async cartao(cartao, check = false) {
    try {
      const c = await this.Cards.findOne({ number: cartao }).populate(
        'level'
      )

      if (check) {
        const response = await this.checker.check(c)

        if (response.success && !response.live) {
          return {
            success: false,
            message: response.message,
            response: response.card,
          }
        } else {
          return {
            success: true,
            message: response.message,
            response: c,
          }
        }
      }

      if (c.restrict) {
        return {
          success: false,
          response: c,
        }
      } else {
        return {
          success: true,
          response: c,
        }
      }
    } catch (e) {
      return { success: false, response: e.message }
    }
  }

  async find(query, options = {}) {
    return this.Cards.findOne(query, options).populate('level')
  }

  async checar(cartao, restrict = false) {
    try {
      const c = await this.Cards.findOne({ number: cartao }).populate(
        'level'
      )
      const response = await this.checker.check(c, restrict)

      if (response.success && !response.live) {
        return {
          success: false,
          message: response.message,
          response: response.card,
        }
      } else {
        return {
          success: true,
          message: response.message,
          response: c,
        }
      }
    } catch (e) {
      console.log(e.message)
    }
  }

  async mix(ignoreAny, value, check = false, filter = []) {
    try {
      const totalCards = await this.Cards.find({
        restrict: false,
      }).populate('level')
      let totalCardsFinal = []

      if (ignoreAny) {
        if (filter.length > 0)
          totalCardsFinal = totalCards
            .filter((card) => {
              return filter.includes(card.level.type)
            })
            .shuffle()
        else
          totalCardsFinal = totalCards
            .filter((card) => {
              return (
                card.level.type != 'BLACK' &&
                card.level.type != 'INFINITE' &&
                card.level.type != 'BUSINESS' &&
                card.level.type != 'AMERICAN EXPRESS'
              )
            })
            .shuffle()
      } else {
        totalCardsFinal = totalCards.shuffle()
      }

      if (check) {
        let cards = []
        let cardsChecked = []

        for (let card of totalCardsFinal) {
          const response = await this.checker.check(card)
          cardsChecked.push(card)

          if (response.success && response.live) {
            cards.push(card)
          } else if (!response.success) {
            cards = totalCardsFinal.slice(
              cardsChecked.length,
              totalCardsFinal.length
            )
            break
          }

          if (cards.length == value) break
        }

        totalCardsFinal = cards
      }

      if (totalCardsFinal.length >= value) {
        return {
          success: true,
          response: totalCardsFinal.shuffle().slice(0, value--),
        }
      } else {
        return {
          success: false,
          response: '<b>Sem estoque disponível para essa mix.</b>',
        }
      }
    } catch (e) {
      console.log(e)
      return {
        success: false,
        response: e.message,
      }
    }
  }

  async saveMix(mix, id) {
    try {
      const fs = require('fs')

      fs.writeFileSync(`${__dirname}/mix/${id}.txt`, mix, {
        flag: 'w',
      })
      const confirm = fs.readFileSync(
        `${__dirname}/mix/${id}.txt`,
        'utf-8'
      )

      return { success: true }
    } catch (e) {
      console.log(e.message)
      return {
        success: false,
        message: '<b>Ocorreu um erro ao executar este comando.',
      }
    }
  }

  async backup(query) {
    try {
      const fs = require('fs')

      const cards = await this.Cards.find(query).populate('level')

      const cardsString = cards
        .map((card) => {
          return `${card.number}|${card.month}|${card.year}|${
            card.cvv
          }|${card.level.type}|${
            card.bin.bank ? card.bin.bank.name : 'Não especificado'
          }`
        })
        .join('\n')

      const cardsBackup = `${
        cardsString.length < 1 ? 'Nada consta' : cardsString
      }`

      fs.writeFileSync(`${__dirname}/backup/cards.txt`, cardsBackup, {
        flag: 'w',
      })
      const confirm = fs.readFileSync(
        `${__dirname}/backup/cards.txt`,
        'utf-8'
      )

      return { success: true }
    } catch (e) {
      console.log(e.message)
      return {
        success: false,
        message: '<b>Ocorreu um erro ao executar este comando.',
      }
    }
  }

  async retirar(query, limit = 10) {
    const Data = require('../../utils/PreferenceFunctions')

    try {
      const fs = require('fs')

      const cards = await this.Cards.find(query)
        .limit(limit)
        .populate('level')

      const removeCards =
        cards.length > 0
          ? Promise.all(
              cards.map(
                async (card) =>
                  await this.Cards.findOneAndUpdate(
                    { number: card.number },
                    { restrict: true }
                  )
              )
            )
          : 0

      const cardsString = cards
        .map((card) => {
          let { name, cpf } = Data.getData()
          return `${card.number}|${card.month}|${card.year}|${
            card.cvv
          }|${card.level.type}|${
            card.bin.bank ? card.bin.bank.name : 'Não especificado'
          }|${name}|${cpf}`
        })
        .join('\n')

      const cardsRetrive = `${
        cardsString.length < 1 ? 'Nada consta' : cardsString
      }`

      fs.writeFileSync(
        `${__dirname}/retirar/cards.txt`,
        cardsRetrive,
        {
          flag: 'w',
        }
      )
      const confirm = fs.readFileSync(
        `${__dirname}/retirar/cards.txt`,
        'utf-8'
      )

      return { success: true, cards: cards }
    } catch (e) {
      console.log(e.message)
      return {
        success: false,
        message: '<b>Ocorreu um erro ao executar este comando.',
      }
    }
  }
}

module.exports = Card
