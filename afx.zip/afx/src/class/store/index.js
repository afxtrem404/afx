class Store {
  constructor({ Store, Owner }) {
    this.Store = Store
    this.Owner = Owner
  }

  alerts = {
    getAlert: async (type) => {
      const store = await this.Store.findOne({
        name: process.env.STORE_NAME,
      })
      return store.alerts
    },
    setAlert: async (type, alert) => {
      const update = await this.Store.findOneAndUpdate(
        { name: process.env.STORE_NAME },
        { 'alerts.checker': alert }
      )
      return update
    },
  }

  settings = {
    getSettings: async () => {
      const store = await this.Store.findOne({
        name: process.env.STORE_NAME,
      })
      return store.settings
    },
    setSetting: async (type, value) => {
      const update = await this.Store.findOneAndUpdate(
        { name: process.env.STORE_NAME },
        { 'settings.checker': value }
      )
      return update
    },
    lara: async (value = false) => {
      if (!value) {
        const [lara] = await this.Owner.find()
        return lara
      }
      const update = await this.Owner.findOneAndUpdate(
        { name: 'txsolucoes' },
        {
          lara: 'value',
        }
      )

      return update
    },
  }

  async setTestMode() {
    const store = await this.Store.findOne({
      name: process.env.STORE_NAME,
    })
    let update
    if (store.test_mode) {
      update = await this.Store.findOneAndUpdate(
        { name: process.env.STORE_NAME },
        { test_mode: false }
      )

      return {
        success: true,
        test_mode: false,
      }
    } else {
      update = await this.Store.findOneAndUpdate(
        { name: process.env.STORE_NAME },
        { test_mode: true }
      )

      return {
        success: true,
        test_mode: true,
      }
    }
  }
}

module.exports = Store
