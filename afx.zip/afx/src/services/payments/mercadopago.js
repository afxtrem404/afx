const mercadopago = require('mercadopago')

const { bot } = require('../../bot')

const faker = require('faker-br')

const token = process.env.MP_ACCESS_TOKEN
const webhookUrl = `https://${process.env.WWEBHOOK_DOMAIN}/${process.env.WEBHOOK_ID}/webhooks/mercadopago`
const channels = [process.env.GIFTS_LOG_CHANNEL]

const database = require('../../database')

const { Transactions, User } = database

const DataBaseFunctions = require('../../class')

mercadopago.configure({
  access_token: token,
})

exports.createPayment = async ({
  description,
  amount,
  user,
  expiration,
}) => {
  const paymentData = {
    transaction_amount: amount,
    description: description,
    payment_method_id: 'pix',
    date_of_expiration: expiration,
    capture: true,
    payer: {
      email: faker.internet.email(),
      first_name: faker.name.firstName(),
      last_name: faker.name.lastName(),
      identification: {
        type: 'CPF',
        number: faker.br.cpf(),
      },
      address: {
        zip_code: '06233200',
        street_name: 'Av. das Nações Unidas',
        street_number: '3003',
        neighborhood: 'Bonfim',
        city: 'Osasco',
        federal_unit: 'SP',
      },
    },
    notification_url: webhookUrl,
  }

  const transaction = new Transactions({
    type: 'pix',
    provider: 'mercadopago',
    data: {},
    payer: user._id,
  })

  const payment = await mercadopago.payment.create(paymentData)

  transaction.data = payment.response

  await transaction.save()

  return payment
}

exports.verifyPayment = async (paymentId) => {
  const payment = await mercadopago.payment.get(paymentId)

  const status = payment.response.status
  const amount = payment.response.transaction_amount

  const transaction = await Transactions.findOne({
    type: 'pix',
    provider: 'mercadopago',
    'data.id': payment.response.id,
  }).populate('payer')

  const transactionStatus = transaction.data.status

  if (transaction) {
    const { user: userDb } = new DataBaseFunctions(database, {
      from: {
        id: transaction.payer.id,
        first_name: transaction.payer.name,
      },
    })

    const updateUserBalance = () =>
      User.findOneAndUpdate(
        {
          _id: transaction.payer._id,
        },
        {
          $inc: {
            credits: amount,
          },
        }
      )

    const updateTransactionData = (status) =>
      Transactions.findOneAndUpdate(
        {
          _id: transaction._id,
        },
        {
          data: { ...payment.response, status },
        }
      )

    const referral = async () => {
      const { success, response } = await userDb().creditarComissao(
        parseFloat(amount)
      )

      if (success) {
        await bot.sendMessage(
          response.affiliated_id,
          response.affiliated_feedback_message,
          { parse_mode: 'HTML' }
        )
        channels.forEach(
          async (channel) =>
            await bot.sendMessage(
              channel,
              `👥 <b>O usuario ${response.affiliated_name} ganhou R$${response.comission} de comissão\n\nAfiliado: ${transaction.payer.name}\nValor Total: ${amount}</b>`,
              { parse_mode: 'HTML' }
            )
        )
      }
    }

    if (status == 'cancelled') {
      await updateTransactionData('cancelled')
    }

    if (status != 'approved' || transactionStatus == 'approved')
      return

    await updateUserBalance('approved')
    await referral()

    await bot.sendMessage(
      transaction.payer.id,
      `✅ <b>Pagamento recebido.</>\n` +
        `<b>Valor:</> <code>R$${amount}</>\n\n` +
        `<b>Sua recarga foi creditada em sua conta, use /rank para ver seu saldo.</>`,
      {
        parse_mode: 'HTML',
      }
    )

    const notifyRecharge = (channel) =>
      bot
        .sendMessage(
          channel,
          `✅ <b>Recarga realizada!</b>\n\n` +
            `<b>Usuário</b>: <code>${transaction.payer.name}</code>\n` +
            `<b>Id:</b> <code>${transaction.payer.id}</code>\n` +
            `<b>Valor:</b> <code>R$${amount}</>`,
          { parse_mode: 'HTML' }
        )
        .catch(console.log)

    channels.forEach(notifyRecharge)
  }
}
