const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function allcenter(card, currentRetrys = 0) {
  const { retrys, allcenter: configs } = getConfig('checkers')

  try {
    const getAuthToken = {
      url: 'https://allcenter.online/auth',
      method: 'POST',
      headers: {
        host: 'allcenter.online',
        accept: 'application/json, text/javascript, */*; q=0.01',
        'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/json',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'x-requested-with': 'XMLHttpRequest',
        referrer: 'https://allcenter.online/',
        referrerPolicy: 'strict-origin-when-cross-origin',
        mode: 'cors',
      },
      json: {
        user: configs.user,
        pass: configs.pass,
      },
      timeout: 100000,
    }

    const { access_token } = await request(getAuthToken)

    const sendCard = {
      url: 'https://allcenter.online/DASH/api/validate',
      method: 'POST',
      headers: {
        host: 'allcenter.online',
        accept: '*/*',
        'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        authorization: 'Bearer ' + access_token,
        'content-type': 'application/json',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'x-requested-with': 'XMLHttpRequest',
        referrer: 'https://allcenter.online/DASH/chk/validate',
        referrerPolicy: 'strict-origin-when-cross-origin',
        mode: 'cors',
      },
      json: {
        lista: `${card.number}|${card.month}|${card.year}|${card.cvv}`,
      },
      timeout: 50000,
    }

    const response = await request(sendCard)

    if (currentRetrys >= retrys)
      return { active: false, output: response }

    const { live, status } = response

    if (!status) {
      currentRetrys++
      return allcenter(card, currentRetrys)
    }

    if (live) {
      return {
        active: true,
        card: card,
        live: true,
        output: response,
      }
    } else {
      return {
        active: true,
        card: card,
        live: false,
        output: response,
      }
    }
  } catch (e) {
    console.log(e)
    currentRetrys++
    if (
      e.message.includes?.('ESOCKETTIMEDOUT') ||
      e.message.includes?.('ETIMEDOUT ')
    )
      return allcenter(card, currentRetrys)

    return { active: false, output: e.message }
  }
}
