const company = require('./company')
const confidence = require('./confidence')
const azkabancenter = require('./azkabancenter')
const warlock = require('./warklock')
const allcenter = require('./allcenter')
const falselive = require('./falselive')
const dbf = require('./dbf')
const luxurious = require('./luxurious')
const playercheckers = require('./playercheckers')
const generic = require('./generic')

module.exports = {
  company,
  confidence,
  azkabancenter,
  warlock,
  allcenter,
  falselive,
  dbf,
  luxurious,
  playercheckers,
  generic,
}
