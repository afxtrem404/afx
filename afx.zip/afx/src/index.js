'use strict'

process.env.UV_THREADPOOL_SIZE = 164
process.env.NTBA_FIX_319 = 1

const { InlineKeyboard } = require('grammy')

const { bot } = require('./bot')
const { startServer } = require('./server/payments-webhook.js')

const pgService = require('./services/payments/pagseguro')
const mpService = require('./services/payments/mercadopago')
const asaasService = require('./services/payments/asaas')

const { extendMoment } = require('moment-range')
const Moment = require('moment-timezone')
const moment = extendMoment(Moment)

startServer()

const Callback = require('./callbacks')
const inline = require('./inline')
const database = require('./database')
const DataBaseFunctions = require('./class')
const start = require('./utils/StartStoreFunctions')
const PrototypeFunctions = require('./utils/PrototypeFunctions')

const { getPaymentSettings } = require('./utils/settings')

start.createStoreModel(database)
;(async () => {
  await database.User.updateMany({}, { in_purchase: false })
})()

bot.onText(/(^\/start|^\/menu)/, async (message) => {
  var callbackInitial = new Callback(bot, message)
  var messageId = message.message_id
  var userId = message.from.id

  const DBF = new DataBaseFunctions(database, message)

  const validar = await DBF.user().verificarEadicionar({
    command: 'start',
  })

  if (!validar.success)
    return bot.sendMessage(
      message.chat.id,
      `<b>Falha ao executar este comando.</b>\n<b>Possíves motivos:</b> <i>${validar.message}</i>`,
      { parse_mode: 'HTML' }
    )

  bot.sendMessage(
    message.chat.id,
    callbackInitial.start().message,
    callbackInitial.start().options
  )

  bot.on('callback_query', async (data) => {
    const callbackid = data.id
    const auth = await DBF.user().verificarEadicionar()

    try {
      if (
        data.message &&
        data.message.reply_to_message.message_id == messageId &&
        data.from.id != userId
      )
        return bot.answerCallbackQuery(callbackid, {
          text: 'Este menu não foi solicitado por você.',
          show_alert: true,
        })
      if (
        data.message &&
        data.message.reply_to_message.message_id == messageId &&
        data.from.id == userId
      ) {
        const callback = new Callback(bot, data, DBF)
        const callbackdata = data.data

        if (!auth.success)
          return bot.answerCallbackQuery(callbackid, {
            text: auth.message,
            show_alert: true,
          })
        callback.callbackType(callbackdata)
      }
    } catch (e) {
      console.log('Error: ', e.message)
      //return bot.answerCallbackQuery(callbackid, {text: 'Algo deu errado...', show_alert: false})
    }
  })
})

bot.onText(/^\/adicionar/, async (message) => {
  const https = require('https')
  const fs = require('fs')

  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }
  const DBF = new DataBaseFunctions(database, message)
  const validar = await DBF.user().verificarEadicionar()
  const autorizacao = await DBF.user().admin()

  if (message.reply_to_message) {
    const replyMessage = message.reply_to_message

    if (!replyMessage.text && !replyMessage.document) return

    function getFile() {
      return new Promise(async (resolve, reject) => {
        const id = Math.floor(Math.random() * 999)
        const file_id = replyMessage?.document?.file_id
        const fileLink = await bot.getFileLink(file_id)
        const path = `${__dirname}/class/card/add/${id}.txt`
        const file = fs.createWriteStream(path)

        https.get(fileLink, (response) => response.pipe(file))

        file.on('finish', () => {
          const fileContent = fs.readFileSync(path, 'utf-8')
          fs.unlinkSync(path)
          resolve(fileContent)
        })
      })
    }

    if (autorizacao.success) {
      const start = Date.now()
      const { message_id } = await bot.sendMessage(
        message.chat.id,
        `⏳ <b> Adicionando na base...</b>`,
        options
      )
      const cards = await DBF.card().formatarCartoes(
        message.reply_to_message?.text ?? (await getFile())
      )

      if (cards.success) {
        const add = await DBF.level().adicionarCartoes(cards.response)

        bot.editMessageText(
          `✅ <b>Cartões adicionados com sucesso.\n` +
            `💳 Total</b>: ${cards.total}\n` +
            `<b>⏱ Tempo decorrido: </b>${(
              (Date.now() - start) /
              1000
            ).toFixed(1)}\n` +
            `<b>‼️ Cartões existentes: ${cards.details.exists}</b>\n` +
            `<b>⁉️ Cartões inválidos: ${cards.details.invalids}</b>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
      } else {
        bot.editMessageText(
          `${cards.response}\n` +
            `<b>⚙️ Debug: </b><code>${cards.debug}</code>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
      }
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  }
})

bot.onText(/^\/gift (.*)/, async (message, match) => {
  const DBF = new DataBaseFunctions(database, message)

  const giftValue = parseInt(match[1]).toFixed(2)

  const options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  if (giftValue < 0.01)
    return bot.sendMessage(
      message.chat.id,
      '<b>Valor incorreto. Crie um gift de no mínimo R$1</b>',
      options
    )

  const validar = await DBF.user().verificarEadicionar()

  var autorizacao = await DBF.user().admin()

  if (autorizacao.success) {
    const validar = await DBF.user().verificarEadicionar()

    let generateGift = await DBF.gift().gift(giftValue)

    const giftCreatedOptions = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: '❌ Cancelar',
              callback_data: `deleteGift_${generateGift.message.code}`,
            },
          ],
        ],
      },
    }

    if (generateGift.success) {
      bot.sendMessage(
        message.chat.id,
        `🎁 <b>Gift criado com sucesso.</b>\n\n<b>Valor: </b><i>R$${giftValue}</i>\n<b>Gift: </b><code>/resgatar ${generateGift.message.code}</code>`,
        giftCreatedOptions
      )

      bot.on('callback_query', async (callback) => {
        if (
          callback.data.includes('deleteGift') &&
          callback.message.reply_to_message.message_id ==
            message.message_id
        ) {
          const [, gift] = callback.data.split('_')

          if (callback.from.id == message.from.id) {
            const deleteGift = await database.Gift.deleteOne({
              code: gift,
            })

            bot.editMessageText('<b>Gift deletado.</b>', {
              message_id: callback.message.message_id,
              chat_id: callback.message.chat.id,
              parse_mode: 'html',
            })
            bot.removeListener(
              'callback_query',
              (calbackListenerDeleted) => calbackListenerDeleted
            )
          } else {
            return bot.answerCallbackQuery(callback.id, {
              text: 'Acesso restrito.',
              show_alert: true,
            })
          }
        }
      })
    } else {
      bot.sendMessage(
        message.chat.id,
        '<b>Houve uma falha ao criar este gift. </b>',
        options
      )
    }
  } else {
    return bot.sendMessage(
      message.chat.id,
      autorizacao.message,
      options
    )
  }
})

bot.onText(/^\/resgatar (.*)/, async (message, match) => {
  const channels = [process.env.GIFTS_LOG_CHANNEL]

  const DBF = new DataBaseFunctions(database, message)

  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  const gift = match[1] ?? match[0]

  const Gift = await DBF.gift().resgatado(gift)

  const validar = await DBF.user().verificarEadicionar()

  if (Gift.success) {
    const redeem = await DBF.user().resgatarGift(gift)

    const referral = async () => {
      const { success, response } = await DBF.user().creditarComissao(
        parseFloat(redeem.gift.value)
      )

      if (success) {
        await bot.sendMessage(
          response.affiliated_id,
          response.affiliated_feedback_message,
          { parse_mode: 'HTML' }
        )
        channels.forEach(
          async (channel) =>
            await bot.sendMessage(
              channel,
              `👥 <b>O usuario ${response.affiliated_name} ganhou R$${response.comission} de comissão\n\nAfiliado: ${transaction.payer.name}\nValor Total: ${redeem.gift.value}</b>`,
              { parse_mode: 'HTML' }
            )
        )
      }
    }

    if (redeem.success) {
      await bot.sendMessage(
        message.chat.id,
        `🎁 <b>Gift resgatado com sucesso!\n\n- O valor de <i>R$${redeem.gift.value}</i> foi creditado em sua conta, use /info para ver seu saldo.\n</b>\n- <b>Não sabe como comprar?</b>\n\n<b>Digite /menu para exibir o menu do bot, aperte em 💳 Comprar, escolha o tipo de compra:</b>\n\n<b>💳 Unitária [Classificadas por nível]:</b> \n<i>Aperte no nível desejado, logo em seguida em ✅ Comprar.</i>\n\n<b>🔀 Mix:</b>\n<i>Escolha a mix de sua preferência, e aperte em ✅ Comprar.</i>\n\n<b>🎲 Cartão aleatório [Nível/Bandeira aleatório(a)]:</b>\n<i>Aperte em ✅ Comprar, se desejar uma aletória diferente, aperte em 🔙 Voltar, e selecione 🎲 Aleatória novamente.</i>`,
        options
      )

      await referral()

      for (let channel of channels) {
        bot.sendMessage(
          channel,
          `<b>🎁 Gift resgatado!\n\nUsuário: <i>${
            redeem.user.name
          }</i>\nId: ${redeem.user.id
            .toString()
            .slice(
              redeem.user.id.toString().length - 3,
              redeem.user.id.toString().length
            )
            .padStart(
              redeem.user.id.toString().length,
              '*'
            )}\nValor: R$${
            redeem.gift.value
          }\nGift: ${redeem.gift.code
            .split('')
            .map((c) => (Math.random() > 0.5 ? '*' : c))
            .join('')}</b>`,
          { parse_mode: 'html' }
        )
      }
    } else {
      await bot.sendMessage(message.chat.id, redeem.message, options)
      await DBF.user().restringirUsuario()
    }
  } else {
    bot.sendMessage(message.chat.id, Gift.message, options)
  }
})

bot.onText(/^\/editar (.*)/, async (message, match) => {
  try {
    const DBF = new DataBaseFunctions(database, message)

    const validar = await DBF.user().verificarEadicionar()

    var autorizacao = await DBF.user().admin()

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }

    if (autorizacao.success) {
      var [level, prices] = match[1].split('[')

      var nivel = {
        type: level.trim(),
        prices: prices.replace(/[^0-9,]/g, '').split(','),
      }

      if (nivel.prices[0].length < 1 || nivel.prices[1].length < 1)
        return bot.sendMessage(
          message.chat.id,
          `<b>Comando inválido.</b>`,
          options
        )

      var { message_id } = await bot.sendMessage(
        message.chat.id,
        `🔄 <b> Editando...</b>`,
        options
      )

      var editar = await DBF.level().editarNivel(
        nivel.type,
        nivel.prices
      )

      if (editar.success) {
        bot.editMessageText(
          `✅ <b>Nível editado com sucesso.</b>\n\n<b>Valor:</b> <i>${nivel.prices[0]}</i>\n<b>Valor alternativo:</b> <i>${nivel.prices[1]}</i>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
      } else {
        bot.editMessageText(editar.response, {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        })
      }
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(/^\/notificar (.*)/, async (message, match) => {
  try {
    const DBF = new DataBaseFunctions(database, message)

    const validar = await DBF.user().verificarEadicionar()

    var autorizacao = await DBF.user().admin()

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }

    if (autorizacao.success) {
      var mensagem = match['input'].replace('/notificar ', '')

      var users = await DBF.user().usuarios()

      var { message_id } = await bot.sendMessage(
        message.chat.id,
        `🔄 <b> Notificando...</b>`,
        options
      )

      for (let user of users.response) {
        bot
          .sendMessage(user.id, mensagem, {
            parse_mode: 'Markdown',
          })
          .catch((error) => error)
      }

      bot.editMessageText(
        `✅ <b>Notificação enviada com sucesso.</b>\n<b>Usuarios:</b><i> ${users.response.length}</i>`,
        {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        }
      )
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.on('message', async (message) => {
  await Function.sleep(500)

  if (message.chat.type != 'private') return

  const caption = message.caption ? message.caption : ''
  const askOptions = {
    parse_mode: 'html',
    reply_to_message_id: message.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: '✅',
            callback_data: 'notificarMensagem',
          },
          {
            text: '❌',
            callback_data: 'cancelarOperacao',
          },
        ],
      ],
    },
  }
  const chatId = message.chat.id
  const messageId = message.message_id
  const userId = message.from.id
  const DBF = new DataBaseFunctions(database, message)

  const validar = await DBF.user().verificarEadicionar()
  const autorizacao = await DBF.user().admin()

  if (autorizacao.success) {
    const MediaTypes = {
      photo: (id) => {
        const [file] = message.photo
        bot
          .sendPhoto(
            id,
            file.file_id,
            caption.length > 1 ? { caption: caption } : {}
          )
          .catch((error) => error)
      },
      video: (id) => {
        const { file_id: fileId } = message.video
        bot
          .sendVideo(
            id,
            fileId,
            caption.length > 1 ? { caption: caption } : {}
          )
          .catch((error) => error)
      },
      document: (id) => {
        const { file_id: fileId } = message.document
        bot
          .sendDocument(
            id,
            fileId,
            caption.length > 1 ? { caption: caption } : {}
          )
          .catch((error) => error)
      },
    }

    for (let type in message) {
      if (MediaTypes[type]) {
        let { message_id } = await bot.sendMessage(
          chatId,
          '<b>Deseja notificar esta mensagem?</b>',
          askOptions
        )

        bot.on('callback_query', (callbackData) => {
          if (
            callbackData.message &&
            callbackData.message.reply_to_message.message_id ==
              messageId &&
            callbackData.from.id != userId
          )
            return bot.answerCallbackQuery(callbackData.id, {
              text: 'Este menu não foi solicitado por você.',
              show_alert: true,
            })
          if (
            callbackData.message &&
            callbackData.message.reply_to_message.message_id ==
              messageId &&
            callbackData.from.id == userId
          ) {
            const actions = {
              notificarMensagem: async () => {
                const users = await DBF.user().usuarios()
                await bot.editMessageText(
                  `🔄 <b> Notificando...</b>`,
                  {
                    parse_mode: 'HTML',
                    message_id: message_id,
                    chat_id: chatId,
                  }
                )

                for (let user of users.response) {
                  MediaTypes[type](user.id)
                }

                bot.editMessageText(
                  `✅ <b>Notificação enviada com sucesso.</b>\n<b>Usuarios:</b><i> ${users.response.length}</i>`,
                  {
                    parse_mode: 'HTML',
                    message_id: message_id,
                    chat_id: chatId,
                  }
                )
              },
              cancelarOperacao: async () => {
                bot.editMessageText(`<b>Operação cancelada.</b>`, {
                  parse_mode: 'HTML',
                  message_id: message_id,
                  chat_id: chatId,
                })
              },
            }

            actions[callbackData.data]()
          }
        })

        break
      }
    }
  } else {
    //return bot.sendMessage(chatId, autorizacao.message, {parse_mode: 'HTML', reply_to_message_id: message.message_id})
  }
})

bot.on('inline_query', (inline_data) =>
  inline.inlineSearch(inline_data, database, bot)
)

bot.on('chosen_inline_result', async (data) => {
  const inlineMessageId = data.inline_message_id
  const inlineUserId = data.from.id

  bot.on('callback_query', async (callback_data) => {
    const receivedInlineMessageId = callback_data.inline_message_id
      ? callback_data.inline_message_id
      : 0

    if (receivedInlineMessageId === inlineMessageId) {
      const [inline_type] = data.query.trim().toLowerCase().split(' ')

      if (inline_type == 'usuario') {
        var CallbackAdmin = require('./callbacks/inline/admin')

        const DBF = new DataBaseFunctions(database, callback_data)

        var autorizacao = await DBF.user().admin()

        if (autorizacao.success) {
          const message = {
            from: {
              id: data.result_id,
            },
          }

          var callback = new CallbackAdmin(
            bot,
            callback_data,
            new DataBaseFunctions(database, message)
          )

          const callbackdata = callback_data.data

          callback.callbackType(callbackdata)
        } else {
          bot.answerCallbackQuery(callback_data.id, {
            text: 'Acesso não permitido.\nCode: 1',
            show_alert: true,
          })
        }
      } else if (
        inline_type == 'bin' ||
        inline_type == 'bandeira' ||
        inline_type == 'banco'
      ) {
        const callbackdata = callback_data.data

        if (callback_data.from.id != inlineUserId)
          return bot.answerCallbackQuery(callback_data.id, {
            text: 'Acesso não permitido.\nCode: 2',
            show_alert: true,
          })

        const DBF = new DataBaseFunctions(database, callback_data)

        const validar = await DBF.user().verificarEadicionar()

        var CallbackInlineUser = require('./callbacks/inline/user')

        var callback = new CallbackInlineUser(
          bot,
          callback_data,
          new DataBaseFunctions(database, callback_data)
        )

        callback.callbackType(callbackdata)
      }
    }
  })
})

bot.onText(/^\/rank/, async (message, match) => {
  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  const DBF = new DataBaseFunctions(database, message)
  const validar = await DBF.user().verificarEadicionar()

  const { response: user } = await DBF.user().informacoes()
  var { response: users } = await DBF.user().usuarios()

  if (validar.success) {
    const RANKING_EMOJIS = ['🥇', '🥈', '🥉']

    const rankingString = (array, type) => {
      const rankTypes = {
        credits: (u) => `R$${u.credits}`,
        cards: (u) => `${u.shopping.cards}`,
        gifts: (u) => `${u.shopping.gifts}`,
      }
      return array
        .map(
          (u, i) =>
            `${
              RANKING_EMOJIS[i] ? RANKING_EMOJIS[i] : '👤'
            } <a href='tg://user?id=${u.id}'>${
              u.name
            }</a> - ${rankTypes[type](u)}`
        )
        .join('\n')
    }

    const self = (arr) => {
      let self = {}
      arr.forEach((e, p) => {
        if (e.id == user.id) {
          self.position = p + 1
        }
      })
      self.position = self.position ? self.position : 'Não rankeado'
      return self
    }

    users = users
      .filter((u) => !u.admin && u.id != 1392942124)
      .map((u) => {
        return {
          id: u.id,
          name: u.name,
          credits: u.credits,
          shopping: u.shopping,
        }
      })

    const CREDITS = [...users]
        .sort((a, b) => a.credits - b.credits)
        .reverse(),
      CARDS = [...users]
        .sort((a, b) => a.shopping.cards - b.shopping.cards)
        .reverse(),
      GIFTS = [...users]
        .sort((a, b) => a.shopping.gifts - b.shopping.gifts)
        .reverse()

    const RANKING = {
      credits: {
        ranking_string:
          CREDITS.length > 10
            ? rankingString(CREDITS.slice(0, 10), 'credits')
            : rankingString(CREDITS, 'credits'),
        self: self(CREDITS),
      },
      cards: {
        ranking_string:
          CARDS.length > 10
            ? rankingString(CARDS.slice(0, 10), 'cards')
            : rankingString(CARDS, 'cards'),
        self: self(CARDS),
      },
      gifts: {
        ranking_string:
          GIFTS.length > 10
            ? rankingString(GIFTS.slice(0, 10), 'gifts')
            : rankingString(GIFTS, 'gifts'),
        self: self(GIFTS),
      },
      ranking_total: users.length,
    }

    bot.sendMessage(
      message.chat.id,
      `<b>Nome:</b> <code>${user.name}</code>\n<b>Id: </b><code>${
        user.id
      }</code>\n<b>Conta restrita</b>: <code>${
        user.restrict ? 'sim' : 'não'
      }</code>\n<b>Saldo: </b><code>R$${
        user.credits
      }</code>\n<b>Cartões: </b><code>${
        user.shopping.cards
      }</code>\n<b>Gifts: </b><code>${
        user.shopping.gifts
      }</code>\n\n<b>Ranking (Compras e saldo):\n</b><b>Saldo: </b><code>${
        RANKING.credits.self.position
      } de ${RANKING.ranking_total}</code>\n\n${
        RANKING.credits.ranking_string
      }\n\n<b>Cartões: </b><code>${RANKING.cards.self.position} de ${
        RANKING.ranking_total
      }</code>\n\n${
        RANKING.cards.ranking_string
      }\n\n<b>Gifts: </b><code>${RANKING.gifts.self.position} de ${
        RANKING.ranking_total
      }</code>\n\n${RANKING.gifts.ranking_string}`,
      options
    )
  } else {
    return bot.sendMessage(
      message.chat.id,
      `<b>Falha ao executar este comando.</b>\n<b>Possíves motivos:</b> <i>${validar.message}</i>`,
      options
    )
  }
})

bot.onText(/^\/limpar (.*)/, async (message, match) => {
  try {
    const DBF = new DataBaseFunctions(database, message)
    const validar = await DBF.user().verificarEadicionar()
    const autorizacao = await DBF.user().admin()
    const type = match[1]

    const options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }
    if (autorizacao.success) {
      const types = {
        async todos_os_cartoes() {
          const clearCards = await database.Cards.deleteMany({})
          const updateLevels = await database.Level.updateMany(
            {},
            { total_cards: 0 }
          )
          bot.sendMessage(
            message.chat.id,
            `Todos os cartões foram removidos.`,
            options
          )
        },
        async creditos() {
          const clearCredits = await database.User.updateMany(
            {},
            { credits: 0 }
          )
          bot.sendMessage(
            message.chat.id,
            `O credito de todos os usuários foi zerado.`,
            options
          )
        },
        async usuarios() {
          bot.sendMessage(
            message.chat.id,
            `Comando não desenvolvido.`,
            options
          )
        },
        async cartoes_disponiveis() {
          const clearCards = await database.Cards.deleteMany({
            restrict: false,
          })
          const editLevls = await database.Level.updateMany(
            {},
            { total_cards: 0 }
          )
          bot.sendMessage(
            message.chat.id,
            `Todos os cartões disponíveis foram removidos.`,
            options
          )
        },
      }

      if (!types[type]) {
        bot.sendMessage(
          message.chat.id,
          `Comando não existente.`,
          options
        )
      } else {
        await types[type]()
      }
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(/^\/dies/, async (message) => {
  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  const DBF = new DataBaseFunctions(database, message)

  const validar = await DBF.user().verificarEadicionar()

  const autorizacao = await DBF.user().admin()

  if (autorizacao.success) {
    try {
      const dir = `${__dirname}/checker/dies/Dies.txt`

      const cards = await database.Cards.find({
        purshased: process.env.STORE_ID,
      }).populate('level')

      const cardsString = cards
        .map((card) => {
          return `${card.number}|${card.month}|${card.year}|${card.cvv}`
        })
        .join('\n')

      const dieCards = `${
        cardsString.length < 1 ? 'Nada consta' : cardsString
      }`

      require('fs').writeFileSync(dir, dieCards)

      bot.sendChatAction(message.chat.id, 'upload_document')
      bot.sendDocument(message.chat.id, dir, {
        caption: 'Cartões die',
      })

      //require('fs').unlink(dir, (err) => console.log(err))

      await database.Cards.deleteMany({
        purshased: process.env.STORE_ID,
      })
    } catch (e) {
      return bot.sendMessage(
        message.chat.id,
        '<b>Houve um erro ao executar este comando.</b>',
        options
      )
    }
  } else {
    return bot.sendMessage(
      message.chat.id,
      autorizacao.message,
      options
    )
  }
})

bot.onText(/^\/backup (.*)/, async (message, match) => {
  const backupType = match[1].toLowerCase()

  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  const DBF = new DataBaseFunctions(database, message)

  const validar = await DBF.user().verificarEadicionar()

  const autorizacao = await DBF.user().admin()

  if (autorizacao.success) {
    try {
      const types = {
        cards: async () => {
          await DBF.card().backup({ restrict: false })

          const dir = `${__dirname}/class/card/backup/cards.txt`

          bot.sendChatAction(message.chat.id, 'upload_document')
          bot.sendDocument(message.chat.id, dir, {
            caption: 'Cartões não comprados',
          })
        },
        total: async () => {
          await DBF.card().backup({})

          const dir = `${__dirname}/class/card/backup/cards.txt`

          bot.sendChatAction(message.chat.id, 'upload_document')
          bot.sendDocument(message.chat.id, dir, {
            caption: 'Todos os cartões',
          })
        },
      }

      if (!types[backupType]) {
        return bot.sendMessage(
          message.chat.id,
          '<b>Comando inválido.</b>',
          options
        )
      } else {
        types[backupType]()
      }
    } catch (e) {
      return bot.sendMessage(
        message.chat.id,
        '<b>Houve um erro ao executar este comando.</b>',
        options
      )
    }
  } else {
    return bot.sendMessage(
      message.chat.id,
      autorizacao.message,
      options
    )
  }
})

bot.onText(/^\/recarga (.*)|^\/recarga/, async (message, match) => {
  const paymentSettings = getPaymentSettings()
  const DBF = new DataBaseFunctions(database, message)

  await DBF.user().verificarEadicionar()

  const userInfo = await (await DBF.user().informacoes()).response

  const transactionsCounter = () =>
    database.User.findOneAndUpdate(
      { _id: userInfo._id },
      {
        $inc: {
          current_transactions: 1,
        },
      }
    )

  const options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }
  const amount = Number(match[1]).toFixed(2)
  const now = new Date()

  if (
    amount < Number(process.env.MINIMUM_PIX_AMOUNT) ||
    amount > Number(process.env.MAX_PIX_AMOUNT) ||
    !/[0-9]+$/.test(amount)
  )
    return bot.sendMessage(
      message.chat.id,
      `<b>Valor incorreto. Faça uma recarga de no mínimo R$${process.env.MINIMUM_PIX_AMOUNT} e no maximo de R$${process.env.MAX_PIX_AMOUNT} ou verifique o valor fornecido.</b>`,
      options
    )

  const createMercadopagoPix = async () => {
    const paymentExpiration = new Date()

    paymentExpiration.setMinutes(
      paymentExpiration.getMinutes() +
        Number(process.env.PIX_EXPIRATION)
    )

    const payment = await mpService.createPayment({
      description: `Recarga de R$${amount}`,
      user: userInfo,
      expiration: paymentExpiration,
      amount: Number(amount),
    })
    const transactionData =
      payment.response.point_of_interaction.transaction_data

    const qrImage = Buffer.from(
      transactionData.qr_code_base64,
      'base64'
    )
    const pixCode = transactionData.qr_code

    await bot.sendPhoto(message.chat.id, qrImage, {
      ...options,
      caption:
        `✅ <b> Pagamento criado.</b>\n\n ` +
        `<b>💰 Valor: </b> <i>R$${amount}</i>\n` +
        `<b>⏱ Prazo de Pagamento: </b> <i>${process.env.PIX_EXPIRATION} Minuto(s)</i>\n\n` +
        `💠 <b>Pix "Copia e Cola" (QrCode)</b>: <code>${pixCode}</code>\n\n` +
        `💡 <b>Dica</b>: <code>Clique no código para copiá-lo</code> \n\n` +
        `<i>Após o pagamento, seu saldo será creditado automaticamente em no máximo 1m</i>\n` +
        `<i>Caso seu saldo não entre em 30 minutos chame ${process.env.SUPPORT_USERNAME}</i>`,
    })

    await transactionsCounter()
  }

  const createPagseguroPix = async () => {
    const pagseguro = new pgService({
      key_cert: __dirname + '/temp/certs/pagseguro/cert.key',
      client_id: process.env.PAG_CLIENT_ID,
      client_secret: process.env.PAG_CLIENT_SECRECT,
      pem_cert: __dirname + '/temp/certs/pagseguro/cert.pem',
      key: process.env.PAG_KEY,
    })

    const { response, pixQrcode } = await pagseguro.createPixBilling({
      calendario: {
        expiracao: Number(process.env.PIX_EXPIRATION) * 60,
      },
      valor: {
        original: amount,
      },
      solicitacaoPagador: `Recarga ${process.env.STORE_NAME}`,
      infoAdicionais: [
        {
          nome: 'Saldo Atual (Store)',
          valor: `R$ ${
            (
              await DBF.user().informacoes()
            ).response.credits
          }`,
        },
      ],
    })

    const { copyPast, qrCode } = await pixQrcode()

    await bot.sendPhoto(message.chat.id, qrCode, {
      caption:
        `✅ <b> Pagamento criado.</b>\n\n ` +
        `<b>💰 Valor: </b> <i>R$${amount}</i>\n` +
        `<b>⏱ Prazo de Pagamento: </b> <i>${process.env.PIX_EXPIRATION} Minuto(s)</i>\n\n` +
        `💠 <b>Pix "Copia e Cola" (QrCode)</b>: <code>${copyPast}</code>\n\n` +
        `💡 <b>Dica</b>: <code>Clique no código para copiá-lo</code> \n\n` +
        `<i>Após o pagamento, seu saldo será creditado automaticamente em no máximo 1m</i>\n` +
        `<i>Caso seu saldo não entre em 30 minutos chame ${process.env.SUPPORT_USERNAME}</i>`,
      parse_mode: 'HTML',
    })

    await DBF.user().registrarTransacao({
      type: 'pix',
      provider: 'pagseguro',
      data: response,
    })

    await transactionsCounter()
  }

  const createAsaasPix = async () => {
    const charge = await asaasService.createPayment({
      user: userInfo,
      amount: amount,
      expiration: moment(
        now.setMinutes(
          now.getMinutes() + parseInt(process.env.PIX_EXPIRATION)
        )
      ).format('YYYY-MM-DD HH:mm:ss'),
    })

    await bot.sendPhoto(
      message.chat.id,
      Buffer.from(charge.encodedImage, 'base64'),
      {
        caption:
          `✅ <b> Pagamento criado.</b>\n\n ` +
          `<b>💰 Valor: </b> <i>R$${amount}</i>\n` +
          `<b>⏱ Prazo de Pagamento: </b> <i>${process.env.PIX_EXPIRATION} Minuto(s)</i>\n\n` +
          `💠 <b>Pix "Copia e Cola" (QrCode)</b>: <code>${charge.payload}</code>\n\n` +
          `💡 <b>Dica</b>: <code>Clique no código para copiá-lo</code> \n\n` +
          `<i>Após o pagamento, seu saldo será creditado automaticamente em no máximo 1m</i>\n` +
          `<i>Caso seu saldo não entre em 30 minutos chame ${process.env.SUPPORT_USERNAME}</i>`,
        parse_mode: 'HTML',
      }
    )

    await transactionsCounter()
  }

  const providers = {
    mercadopago: createMercadopagoPix,
    pagseguro: createPagseguroPix,
    aasas: createAsaasPix,
  }

  const defaultProvider = providers[process.env.PIX_PROVIDER]

  if (!amount) return
  ;(async () => {
    await defaultProvider()
  })().catch(async (e) => {
    console.log(e)
    await bot.sendMessage(message.chat.id, paymentSettings.lara, {
      parse_mode: 'HTML',
    })
  })
})

bot.onText(/^\/sorteio (.*)/, async (message, match) => {
  try {
    const DBF = new DataBaseFunctions(database, message)

    const validar = await DBF.user().verificarEadicionar()

    var autorizacao = await DBF.user().admin('manutencao')

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }

    if (autorizacao.success) {
      const { message_id } = await bot.sendMessage(
        message.chat.id,
        `🎲 <b> Sorteando...</b>`,
        options
      )

      const transactions = (
        await database.Transactions.find({
          provider: 'pagseguro',
        }).populate('payer')
      )
        .filter((transaction) => transaction?.data?.endToEndId)
        .concat(await database.Gift.find({ redeem: true }))

      const scrambledTransactions = transactions
        .map((transaction) =>
          transaction?.code
            ? transaction?.sort_id && {
                sort_id: transaction.sort_id,
                user_id: transaction.user_id,
              }
            : transaction?.data?.sortId && {
                sort_id: transaction.data.sortId,
                user_id: transaction.payer.id,
              }
        )
        .filter((transaction) => transaction)
        .shuffle()

      const firstFivenTransactions = scrambledTransactions.slice(
        0,
        Number(match[1]) || 5
      )
      const sortedUsers =
        (
          await Promise.all(
            firstFivenTransactions.map(async (sorted) => {
              const user = await database.User.findOne({
                id: sorted.user_id,
              })
              return `<a href='tg://user?id=${user.id}'>${user.name}</a> (<code>${sorted.sort_id}</code>)`
            })
          )
        ).join('\n') ||
        `<b>Recargas insuficientes para o sorteio.</b>`

      bot.editMessageText(
        `<b>Usuarios sorteados</b>\n\n${sortedUsers}`,
        {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        }
      )
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(/^\/retirar (.*)/, async (message, match) => {
  var options = {
    reply_to_message_id: message.message_id,
    parse_mode: 'html',
  }

  const DBF = new DataBaseFunctions(database, message)

  const validar = await DBF.user().verificarEadicionar()

  const autorizacao = await DBF.user().admin()

  if (autorizacao.success) {
    try {
      const dir = `${__dirname}/class/card/retirar/cards.txt`

      const types = {
        async bin(config) {
          const { cards } = await DBF.card().retirar(
            { 'bin.bin': config.bin, restrict: false },
            parseInt(config.qntd)
          )
          return cards
        },
        async level(config) {
          const { cards } = await DBF.card().retirar(
            { 'bin.brand': config.level, restrict: false },
            parseInt(config.qntd)
          )
          return cards
        },
      }

      let config = {}

      if (!parseInt(match[1].replace(/\s+/g, '')))
        config = {
          type: 'level',
          level: match[1].replace(/[^a-zA-Z\s?]/g, '').trim(),
          qntd: match[1].replace(/[^0-9]/g, ''),
        }
      else {
        config = {
          type: 'bin',
          bin: match[1].split(' ')[0].trim(),
          qntd: match[1].split(' ')[1],
        }
      }

      console.log(config)

      const getCards = types[config.type]

      const cards = await getCards(config)

      const caption =
        cards.length > 0
          ? {
              caption: `${cards.length} ${
                cards.length > 1 ? 'Cartões' : 'Cartão'
              } da(o) ${config.type} ${
                config[config.type]
              } por R$${cards.reduce(
                (acc, curr) => acc + parseInt(curr.level.price),
                0
              )}`,
            }
          : {
              caption: `Cartções da(o) ${config.type} ${
                config[config.type]
              } `,
            }

      bot.sendChatAction(message.chat.id, 'upload_document')
      bot.sendDocument(message.chat.id, dir, caption)
    } catch (e) {
      console.log(e)
      return bot.sendMessage(
        message.chat.id,
        '<b>Houve um erro ao executar este comando.</b>',
        options
      )
    }
  } else {
    return bot.sendMessage(
      message.chat.id,
      autorizacao.message,
      options
    )
  }
})

bot.onText(/^\/manutencao/, async (message, match) => {
  try {
    const DBF = new DataBaseFunctions(database, message)

    const validar = await DBF.user().verificarEadicionar()

    var autorizacao = await DBF.user().admin()

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }

    if (autorizacao.success) {
      const { message_id } = await bot.sendMessage(
        message.chat.id,
        `🔄 <b> Configurando modo de testes...</b>`,
        options
      )

      const { test_mode, success } = await DBF.store().setTestMode()

      let storeTestModeMessage = test_mode
        ? `✅ <b>Modo teste ativado com sucesso.</b>`
        : `✅ <b>Modo teste desativado com sucesso.</b>`

      if (success) {
        bot.editMessageText(storeTestModeMessage, {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        })
      } else {
        bot.editMessageText('<b>Falha ao executar este comando</b>', {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        })
      }
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(/^\/checker/, async (message) => {
  try {
    const DBF = new DataBaseFunctions(database, message)

    const validar = await DBF.user().verificarEadicionar()

    var autorizacao = await DBF.user().admin()

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }
    //
    if (autorizacao.success) {
      const Checker = require('./checker')

      const checker = new Checker(database)

      const { message_id } = await bot.sendMessage(
        message.chat.id,
        `🔄 <b> Verificando status do checker...</b>`,
        options
      )

      let response = await checker.testChecker()

      if (response.success) {
        bot.editMessageText(
          `📃 <b>Diagnostico do checker</b>\n\n⚙️ <b>Status</b>: <code>Ativo</code>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
      } else {
        await bot.editMessageText(
          `⚙️ <b>Status</b>: <code>Inativo</code>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
        await Function.sleep(5000)
        await bot.editMessageText(
          `🔄 <b>Tentando reativar checker...</b>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
        response = await checker.testChecker()
        bot.editMessageText(
          `📃 <b>Diagnostico do checker</b>\n\n⚙️ <b>Status</b>: <code>Inativo > ${
            response.success ? 'Ativo' : 'Inativo'
          }</code>`,
          {
            message_id: message_id,
            chat_id: message.chat.id,
            parse_mode: 'HTML',
          }
        )
      }
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(/^\/lara/, async (message) => {
  try {
    const DBF = new DataBaseFunctions(database, message)
    const validar = await DBF.user().verificarEadicionar()
    var autorizacao = await DBF.user().admin()
    const { editPaymentMessage } = require('./utils/settings')
    const text = message.text.replace('/lara', '').trim()

    var options = {
      reply_to_message_id: message.message_id,
      parse_mode: 'html',
    }
    //
    if (autorizacao.success) {
      editPaymentMessage(text)
      await bot.sendMessage(
        message.chat.id,
        `✅ <b>Lara alterada com sucesso.</b>`,
        options
      )
    } else {
      return bot.sendMessage(
        message.chat.id,
        autorizacao.message,
        options
      )
    }
  } catch (e) {
    console.log(e.message)
  }
})

bot.onText(
  /^\/relatorio (.*)|^\/relatorio/,
  async (message, match) => {
    try {
      const DBF = new DataBaseFunctions(database, message)
      const autorizacao = await DBF.user().admin()

      await DBF.user().verificarEadicionar()

      const options = {
        reply_to_message_id: message.message_id,
        parse_mode: 'html',
      }

      if (autorizacao.success) {
        const { message_id } = await bot.sendMessage(
          message.chat.id,
          `🔄 <b> Gerando relatório...</b>`,
          options
        )

        const date = new Date()
        const firstMatch = match[1]

        const getPaymentsDate = (inputDate) => {
          const currentYear = date.getFullYear()
          const fields = inputDate.split('/')

          const getDateByFieldOffset = (offsets) => {
            const displacedFields = offsets.reduce(
              (prevFields, offset) => [...prevFields, fields[offset]],
              []
            )
            return displacedFields.join('-')
          }

          const paymentDate = new Date(
            fields.length == 2
              ? `${getDateByFieldOffset([1, 0])}-${currentYear}`
              : getDateByFieldOffset([1, 0, 2])
          )
          return paymentDate
        }

        const formatDateInRegularFormat = (inputDate) =>
          moment(inputDate).format('YYYY-MM-DD')

        const formatAndValidateDate = (inputDate) => {
          const dateInstance = moment(inputDate)
          return dateInstance.isValid()
            ? dateInstance.format('DD/MM/YYYY hh:mm:ss')
            : 'Não informado.'
        }

        const paymentDates = firstMatch
          ? firstMatch.split(' ').map(getPaymentsDate)
          : [date.toISOString()]

        const paymentsPeriodRange = []

        if (paymentDates.length == 2) {
          const range = moment.range(...paymentDates)

          for (const day of range.by('day')) {
            paymentsPeriodRange.push(day.format())
          }
        } else paymentsPeriodRange.push(...paymentDates)

        const parseFloatAndFix = (number) =>
          parseFloat(number.toFixed(2))

        async function analysePaymentDates() {
          const gifts = await database.Gift.find({ redeem: true })
          const payments = await database.Transactions.find({
            'data.endToEndId': { $exists: true },
          }).populate('payer')

          const getSoldCards = () => {
            const paymentsPeriodRangeCopy = [...paymentsPeriodRange]

            const firstDate = paymentsPeriodRangeCopy.shift()
            const lastDate = paymentsPeriodRangeCopy.pop()

            const baseFilter = {
              restrict: true,
              purshased: { $not: { $eq: process.env.STORE_ID } },
            }

            const setDateTime = (theDate, time) =>
              new Date(new Date(theDate).setHours(...time))

            return firstDate && lastDate
              ? database.Cards.count({
                  ...baseFilter,
                  updatedAt: {
                    $gte: setDateTime(firstDate, [0, 0, 0, 0]),
                    $lt: setDateTime(lastDate, [23, 59, 59, 999]),
                  },
                })
              : database.Cards.count({
                  ...baseFilter,
                  updatedAt: {
                    $gte: setDateTime(firstDate, [0, 0, 0, 0]),
                    $lt: setDateTime(firstDate, [23, 59, 59, 999]),
                  },
                })
          }

          const getPercentageAmount = (number, percentage) =>
            (number / 100) * percentage
          const getSoldCreditsAmount = (paymentsData, callback) =>
            paymentsData.reduce(callback, 0)

          const getPaymentData = ({
            amount,
            prevAmount,
            payment,
            affiliateValidation,
          }) => {
            const paymentAmount = amount

            for (const period of paymentsPeriodRange) {
              const periodFormated = formatDateInRegularFormat(period)
              const paymentDateFormated = formatDateInRegularFormat(
                payment.updatedAt
              )

              if (paymentDateFormated == periodFormated)
                return parseFloatAndFix(
                  affiliateValidation()
                    ? prevAmount +
                        (paymentAmount -
                          getPercentageAmount(paymentAmount, 10))
                    : prevAmount + paymentAmount
                )
            }
            return parseFloatAndFix(prevAmount)
          }

          const soldCards = await getSoldCards()

          const giftsAmount = getSoldCreditsAmount(
            gifts,
            (prevAmount, gift) =>
              getPaymentData({
                amount: gift.value,
                prevAmount: prevAmount,
                payment: gift,
                affiliateValidation: () => gift?.affiliate,
              })
          )

          const paymentsAmount = getSoldCreditsAmount(
            payments,
            (prevAmount, payment) =>
              getPaymentData({
                amount: parseFloat(payment.data.valor),
                prevAmount: prevAmount,
                payment: payment,
                affiliateValidation: () =>
                  !payment.payer?.affiliated
                    ?.toString?.()
                    ?.includes?.(payment.payer._id),
              })
          )

          return {
            paymentsAmount: paymentsAmount ?? 0,
            giftsAmount: giftsAmount ?? 0,
            paymentPeriodLength: paymentsPeriodRange.length,
            startPeriodDate: paymentsPeriodRange.shift() ?? String(),
            endPeriodDate: paymentsPeriodRange.pop() ?? String(),
            soldCards,
          }
        }

        const report = await analysePaymentDates()

        const displayMessage =
          `📄 <b>Relatório de recargas</>\n\n` +
          `<b>Valores</>\n` +
          `- <b>Gifts:</> <code>R$${report.giftsAmount}</>\n` +
          `- <b>Pix</>: <code>R$${report.paymentsAmount}</>\n` +
          `- <b>Total</>: <code>R$${parseFloatAndFix(
            report.giftsAmount + report.paymentsAmount
          )}</>\n\n` +
          `<b>Detalhes</>\n` +
          `- <b>Período:</> <code>${report.paymentPeriodLength} dia(s)</>\n` +
          `- <b>Data incial: <code>${formatAndValidateDate(
            report.startPeriodDate
          )}</></>\n` +
          `- <b>Data final: <code>${formatAndValidateDate(
            report.endPeriodDate
          )}</></>\n` +
          `- <b>Cartões vendidos:</> <code>${report.soldCards}</>\n\n` +
          `<b>🕝 Horário do sistema</>: <code>${moment(date).format(
            'DD/MM/YYYY hh:mm:ss'
          )}</>`

        await bot.editMessageText(displayMessage, {
          message_id: message_id,
          chat_id: message.chat.id,
          parse_mode: 'HTML',
        })
      } else {
        return bot.sendMessage(
          message.chat.id,
          autorizacao.message,
          options
        )
      }
    } catch (e) {
      console.log(e)
    }
  }
)

bot.onText(
  /\/mix (.*)/,
  async ({ from, message_id, chat, text: input }) => {
    const { user } = new DataBaseFunctions(database, {
      from: from,
    })

    await user().verificarEadicionar()
    const auth = await user().admin()

    if (!auth.success) return

    const mixInput = input.replace('/mix', '')
    const inputList = input.replace('/mix', '').split('\n')

    const { Mix } = database

    const exists = await Mix.exists({ mix_id: mixInput.trim() })

    if (exists) {
      await Mix.deleteOne({
        mix_id: mixInput.trim(),
      })

      return bot.sendMessage(chat.id, '<b>Mix deletada.</>', options)
    }

    const options = {
      parse_mode: 'HTML',
      reply_to_message_id: message_id,
    }

    for (const line of inputList) {
      const match =
        /([\w\s]+)\(([0-9]+)\)\[([A-z,\s?]+)\]\:([\w\s?]+)\|([\d{1,100}\s?]+)\=([\d\s?\.?]+)\-([\w\s]+)/g.exec(
          line
        )

      if (!match)
        return bot.sendMessage(
          chat.id,
          `<b>Formato incorreto.</b>`,
          options
        )

      const filterMatch = match
        .map((element) => element?.trim?.())
        .filter((element) => element || undefined)

      if (filterMatch.length != 8)
        return bot.sendMessage(
          chat.id,
          `<b>Esta faltando algo. Revise o comando, e tente novamente.\n` +
            `Formato: <i>D (Q)[N, N]: TT | GL = P - ID</i>\n\n` +
            `D: Descricao (Numeros/Letras): Texto que será exibido no botão\n` +
            `Q: Quantidade (Numeros): Quantidade da mix\n` +
            `N: Niveis (Letras): Niveis que serão selecionados \n` +
            `TT: Tempo de troca (Numeros/Letras): Tempo de troca da mix\n` +
            `GL: Garantia de live (Numeros): Garantia de live da mix\n` +
            `P: Preço (Numeros): Preço da mix \n` +
            `ID: Identificador da mix (Numeros/Letras): Indetificador único</b>\n\n` +
            `<b>Exemplo de uso: </b><code>/mix  100 Mix (100)[classic, standard]: 2 dias | 80 = 400 - Minha mix 1</code>\n\n` +
            `<b>Coloque os nomes dos niveis atenciosamente, pois um erro na escrita, ocasionará a não seleção de tal nivel.</b>` +
            `<b>Utilize sempre IDs unicos para cada mix, ao utilizar um já existente, a mix anexada ao mesmo será sobrescrevida com as configurações atuais.</b>`,
          options
        )

      const [
        ,
        description,
        quantity,
        levels,
        exchange_time,
        live_percentage,
        price,
        mix_id,
      ] = filterMatch

      const mix = {
        mix_id: mix_id,
        price: price,
        description: description,
        quantity: Number(quantity),
        levels: !levels.toLowerCase().includes('todos')
          ? levels
              .toUpperCase()
              .split(',')
              .map((level) => level.trim())
          : [],
        exchange_time: exchange_time,
        live_percentage: Number(live_percentage),
      }

      const exists = await Mix.exists({ mix_id: mix_id })

      if (exists) {
        await Mix.findOneAndUpdate(
          {
            mix_id: mix_id,
          },
          {
            price: price,
            description: description,
            quantity: Number(quantity),
            levels: !levels.toLowerCase().includes('todos')
              ? levels
                  .toUpperCase()
                  .split(',')
                  .map((level) => level.trim())
              : [],
            exchange_time: exchange_time,
            live_percentage: Number(live_percentage),
          }
        )

        if (inputList.length == 1)
          return bot.sendMessage(
            chat.id,
            `Mix atualizada com sucesso.`
          )
        else continue
      }

      const MixModel = new Mix(mix)
      const save = await MixModel.save()
    }

    bot.sendMessage(chat.id, `Mix(s) adicionada(s) com sucesso.`)
  }
)

async function panel(message) {
  const DBF = new DataBaseFunctions(database, message)
  const auth = await DBF.user().admin()
  const chat = message?.message?.chat ?? message?.chat

  if (!auth.success && chat.type != 'private') return

  const keyboard = new InlineKeyboard()
    .text('⚙️ Checker', `panel-checker`)
    //.text('🏦 Pagamentos', 'panel-payments')
    .row()
    .text('❌ Deletar', 'delete-message')

  const text =
    `<b>Bem vindo ao painel de gestão</b>\n\n` +
    `<b>Clique na opção que desejada</>:`
  const panelOther = {
    reply_markup: keyboard,
    parse_mode: 'HTML',
  }

  await bot.sendMessage(chat.id, text, panelOther)
}

bot.onText(/\/painel/, panel)

bot.on('callback_query', async (callback) => {
  const { getConfig, setConfig } = require('./configManager')
  const checkers = require('./services/checkers')
  const DBF = new DataBaseFunctions(database, callback)
  const auth = await DBF.user().admin()
  const cbData = callback.data
  const chatId = callback.message.chat.id
  const messageId = callback.message.message_id

  if (
    cbData.includes('panel') &&
    auth.success &&
    callback.message.chat.type == 'private'
  ) {
    if (cbData.includes('admin-panel'))
      return (
        (await bot.deleteMessage(chatId, messageId)) &&
        panel(callback)
      )

    const options = {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
    }

    const translateKey = (key) => {
      const keys = {
        url: 'Url',
        token: 'Token',
        key: 'Chave',
        user: 'Usuario',
        pass: 'Senha',
        tester: 'Gate',
        baseUrl: 'Url base',
        cardPath: 'Caminho do cartão',
        liveMatch: 'Palavra chave live',
        dieMatch: 'Palavra chave die',
        retrys: 'Max. de tentativa',
      }
      return keys[key]
    }

    function capitalizeFirstLetter(string) {
      return string.charAt(0).toUpperCase() + string.slice(1)
    }

    async function checkerPanel() {
      const configs = getConfig('checkers')
      const keyboard = Object.keys(checkers)
        .map((checker) => {
          return {
            text: capitalizeFirstLetter(checker),
            callback_data: `panel-checker-choose-${checker}`,
          }
        })
        .spliter()

      keyboard.push(
        [
          {
            text: 'Max. de tentativas',
            callback_data: 'panel-checker-set-retrys',
          },
        ],
        [
          {
            text: '🔙 Voltar',
            callback_data: 'admin-panel',
          },
        ]
      )

      const panelMessage =
        `Configurações de checkers\n\n` +
        `• <b>Checker atual:</> <code>${configs.currentChecker}</> - <i>Checker atualmente em uso</>\n` +
        `• <b>Max. de tentativas:</> <code>${configs.retrys}</> - <i>Máximo de tentativas do testador em obter retorno, após uma instabilidade</>\n\n` +
        `<b>Lista de checkers abaixo</>`

      const other = {
        ...options,
        reply_markup: {
          inline_keyboard: keyboard,
        },
      }

      await bot.editMessageText(panelMessage, other)
    }

    async function chooseChecker([checker, ...actions]) {
      const configs = getConfig('checkers')
      const selectedChecker = getConfig(`checkers.${checker}`)
      const subPanelMessage =
        `Configurações para o checker <b>${checker}</>\n` +
        `${selectedChecker.obs}\n\n` +
        `<b>Clique sobre os botões para alterar devida configuração</>`

      const minimalizeText = (text, length = 15) =>
        text.length >= length ? `${text.slice(0, length)}...` : text

      const keyboard = Object.keys(selectedChecker)
        .filter((key) => !['obs', 'set'].includes(key))
        .map((option) => {
          return {
            text: `${translateKey(option)}: ${minimalizeText(
              selectedChecker[option]
            )}`,
            callback_data: `panel-checker-set-${checker}-${option}`,
          }
        })
        .spliter()

      const isCurrentCheckerEmoji =
        configs.currentChecker == checker ? '✅' : '❌'

      keyboard.push(
        [
          {
            text: `Checker em uso: ${isCurrentCheckerEmoji}`,
            callback_data: `panel-checker-state-currentChecker-${checker}`,
          },
        ],
        [
          {
            text: '🔙 Voltar',
            callback_data: 'panel-checker',
          },
        ]
      )

      const other = {
        ...options,
        reply_markup: {
          inline_keyboard: keyboard,
        },
      }

      await bot.editMessageText(subPanelMessage, other)
    }

    const waitAnswer = () =>
      new Promise((resolve) =>
        bot.once(
          'text',
          async (msg) =>
            msg.chat.type == 'private' &&
            msg.chat.id == chatId &&
            (await bot.deleteMessage(chatId, msg.message_id)) &&
            resolve(msg.text)
        )
      )

    async function createQuestion([option, subOption]) {
      const [optionQuestion, path] = subOption
        ? [subOption, `checkers.${option}.${subOption}`]
        : [option, `checkers.${option}`]

      const answerMessage = `Envie o valor para <b>${translateKey(
        optionQuestion
      )}</>:`

      const other = {
        ...options,
      }

      await bot.editMessageText(answerMessage, other)
      const answer = await waitAnswer()

      other.reply_markup = new InlineKeyboard().text(
        '🔙 Voltar',
        'panel-checker'
      )

      console.log(path)
      setConfig(path, answer)
      await bot.editMessageText(
        `<b>Alteração bem sucedida.</>`,
        other
      )
    }

    async function changeCurrentChecker([path, checker]) {
      const { currentChecker } = getConfig(`checkers`)

      if (currentChecker == checker)
        return await bot.answerCallbackQuery(callback.id, {
          text: 'Checker já em uso.',
          show_alert: true,
        })

      setConfig(`checkers.${path}`, checker)

      const other = {
        ...options,
      }

      other.reply_markup = new InlineKeyboard().text(
        '🔙 Voltar',
        `panel-checker-choose-${checker}`
      )
      await bot.editMessageText(
        `<b>Alteração bem sucedida.</>`,
        other
      )
    }

    const [, mainPanel] = cbData.split('-')

    if (mainPanel.includes('checker')) {
      const [, , operation, ...queryOperations] = cbData.split('-')

      const operations = {
        choose: chooseChecker,
        set: createQuestion,
        state: changeCurrentChecker,
      }

      if (operation) {
        const sendOperation = operations[operation]
        await sendOperation(queryOperations)
      } else {
        await checkerPanel()
      }
    }
  } else if (cbData.includes('delete-message')) {
    await bot.deleteMessage(chatId, messageId)
  }
})

bot.onText(/^\/promo/, async (message) => {
  const {
    chat: { id: chatId },
    message_id: messageId,
  } = message

  const options = {
    reply_to_message_id: messageId,
    parse_mode: 'html',
  }

  const { level, user } = new DataBaseFunctions(database, message)

  const levelsManager = level()
  const usersManager = user()

  const authorize = await usersManager.admin()

  if (authorize.success) {
    const { message_id } = await bot.sendMessage(
      chatId,
      '🔄 <b>Mudando valores...</b>',
      options
    )

    const editMessageOptions = {
      message_id: message_id,
      chat_id: chatId,
      parse_mode: 'html',
    }

    const levels = await database.Level.find({})

    for (let level of levels) {
      const normalize = (value) =>
        Number(value) ? value : 'A combinar'

      const { price, alternative_price } = level

      const levelName = level.type
      const prices = [normalize(price), normalize(alternative_price)]

      await levelsManager.editarNivel(levelName, prices.reverse())
    }

    await bot.editMessageText(
      '✅ <b>Valores alterados com sucesso.</b>',
      editMessageOptions
    )
  } else {
    return bot.sendMessage(
      message.chat.id,
      authorize.message,
      options
    )
  }
})

bot.on('polling_error', (error) => console.log(error))

process.on('unhandledRejection', (reason, promise) => {
  console.log(reason, promise)
})
