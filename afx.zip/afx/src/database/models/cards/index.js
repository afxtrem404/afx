'use strict'

const mongoose = require('mongoose')

const Schema = mongoose.Schema
const schema = new Schema(
  {
    number: {
      required: true,
      unique: true,
      type: String,
    },
    month: {
      type: String,
      required: true,
    },
    year: {
      type: String,
      required: true,
    },
    cvv: {
      type: String,
      required: true,
    },
    level: {
      type: Schema.Types.ObjectId,
      ref: 'Level',
      required: true,
    },
    bin: {
      type: Object,
      required: true,
    },
    restrict: {
      type: Boolean,
      required: true,
    },
    purshased: {
      type: Number,
      required: true,
    },
    full: {
      type: Boolean,
    },
    holderName: {
      type: String,
    },
    holderCpf: {
      type: String,
    },
  },
  { timestamps: true }
)

module.exports = schema
